function Quiz() {
  var question1 = prompt("What kind of hair does Donald Trump have?");

  if (question1 === "corn hair") {
    alert("YOU ARE CORRECT!")
  } else {
    alert("YOU ARE WRONG!");
  }
  var question2 = prompt("Is Donald Trump the grinch or a human?");

  if (question2 === "grinch")
    alert("YOU ARE CORRECT!")
  else
    alert("YOU ARE WRONG!");

  var question3 = prompt("Is Donald Trump good or evil?");

  if (question3 === "evil") {
    alert("YOU ARE RIGHT!")
  } else {
    alert("YOU ARE INCORRECT!");
  }
  var question4 = prompt("What is Donald Trumps secret plans?");

  if (question4 === "is to end human speices and make a new generation of grinches") {
    alert("YOU ARE perfect and smart!")
  } else {
    alert("YOU ARE STOOPID!");
  }
  var question5 = prompt("What is Donald Trump's real name?");

  if (question5 === "Mr.Cornch") {
    alert("Brilliant!")
  } else {
    alert("denied!");
  }
}